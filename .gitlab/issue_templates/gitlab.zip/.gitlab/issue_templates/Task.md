## Task Summary
_A brief description of what this task is about._


## Acceptance Criteria
_List what must be true for this task to be considered done._

- [ ] Clear success condition 1  
- [ ] Clear success condition 2  
- [ ] Clear success condition 3  

---

## Task Details
**Due date:** YYYY-MM-DD  
**Labels:** `feature` `backend` `frontend` (adjust as needed)
